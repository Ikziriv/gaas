<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Produk;
use App\Models\DetailProduk;
use App\Models\Kategori;
use Carbon\Carbon;

class ProdukController extends Controller
{
	public function index()
	{
        $produks = DB::table('produks')->simplePaginate(10); 
        $tbg1 = DB::table('detail_produks')->where('detail_produks.detial_produk_id', '=', 1)->sum('stock');
        $tbg2 = DB::table('detail_produks')->where('detail_produks.detial_produk_id', '=', 2)->sum('stock');
        $tbg3 = DB::table('detail_produks')->where('detail_produks.detial_produk_id', '=', 3)->sum('stock');
        $tbg4 = DB::table('detail_produks')->where('detail_produks.detial_produk_id', '=', 4)->sum('stock');
        $tbg5 = DB::table('detail_produks')->where('detail_produks.detial_produk_id', '=', 5)->sum('stock');
        $tbg6 = DB::table('detail_produks')->where('detail_produks.detial_produk_id', '=', 6)->sum('stock');
        return view('admin.pages.produk.index', ['produks' => $produks])
        ->with('tbg1', $tbg1)
        ->with('tbg2', $tbg2)
        ->with('tbg3', $tbg3)
        ->with('tbg4', $tbg4)
        ->with('tbg5', $tbg5)
        ->with('tbg6', $tbg6);
	}

	public function create()
	{
        return view('admin.pages.produk.create');
	}

    public function show($id)
    {
    $produk = Produk::find($id);
    $details = DB::table('detail_produks')
    ->leftJoin('produks', 'produks.id', '=', 'detail_produks.detial_produk_id')
    ->where("produks.id",$id)
    ->get(); 
    $total = DB::table('detail_produks')->where("detail_produks.detial_produk_id",$id)->sum('stock');
    return view('admin.pages.produk.show')->with('produk', $produk)->with('details', $details)->with('total', $total);
    }

    public function createProduk(Request $request)
    {
        // $detail = DetailProduk::find($request->id);
        // $detail->stock = $request->stock
        // $detail->save();
        // return response()->json($detail);
    }

	public function edit()
	{
        return view('admin.pages.produk.edit');
	}

    public function editProduk(Request $request)
    {
        // $produk = Produk::find($request->id);
        // $produk->nama = $request->nama
        // $produk->save();
        // return response()->json($produk);
    }
}
