<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Repositories\CustomerRepository;
use App\Repositories\PesananStatRepository;
use App\Models\Transaksi;
use App\Models\Customer;
use App\Models\Pesanan;
use Carbon\Carbon;

class TransaksiController extends Controller
{
    protected $customerRepository;

    protected $pesananStatRepository;

    public function __construct(CustomerRepository $customerRepository)
    {
        $this->customerRepository = $customerRepository;
    }

	public function index(PesananStatRepository $pesananStatRepository, $stat = 'total')
	{
        $transaksis = $this->customerRepository->getCustomerWithStat('10', $stat);
        $counts = $this->customerRepository->counts();
        $status = $pesananStatRepository->all();
        return view('admin.pages.transaksi.index', compact('transaksis', 'counts', 'status'));
	}

    public function getCustomer(Request $request)
    {
        $request_data = $request->all();
        $user_id = $request_data['id'];
        $user_data = DB::table('customers')->where('id', $user_id)->first();        
        return response()->json($user_data);
    }

    public function create()
    {
        $cnames = Customer::pluck('name', 'id');
        $ctlp = Customer::pluck('tlp', 'id');
        return view('admin.pages.transaksi.create', compact('cnames', 'ctlp'));
    }

	public function edit()
	{
        return view('admin.pages.transaksi.edit');
	}

	public function getReport()
	{
        return view('admin.pages.transaksi.report');
	}
}
