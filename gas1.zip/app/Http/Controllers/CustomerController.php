<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Customer;

class CustomerController extends Controller
{
	public function index()
	{
        $customers = DB::table('customers')->simplePaginate(10); 
        return view('admin.pages.customer.index', ['customers' => $customers]);
	}

    public function getCustomer(Request $request)
    {
        $request_data = $request->all();
        $user_id = $request_data['id'];
        $user_data = Customer::where('id', $user_id)->first();
        return response()->json($user_data);
    }

	public function create()
	{
        return view('admin.pages.customer.create');
	}

    public function show($id)
    {
    $customer = Customer::find($id);
    $orders = DB::table('pesanans')
    ->leftJoin('customers', 'customers.id', '=', 'pesanans.customer_id')
    ->leftJoin('produks', 'produks.id', '=', 'pesanans.produk_id')
    ->where("customers.id",$id)
    ->select('produks.nama as p_nama', 'pesanans.qty as qty', 'pesanans.created_at as created_at')
    ->simplePaginate(10); 
    $total = DB::table('pesanans')->where("pesanans.customer_id",$id)->sum('qty');
    return view('admin.pages.customer.show')->with('customer', $customer)->with('orders', $orders)->with('total', $total);
    }

	public function edit()
	{
        return view('admin.pages.customer.edit');
	}
}
