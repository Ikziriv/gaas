<?php

namespace App\Http\Middleware;

use Closure;

class CheckRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $roles = $this->ambilRoleRoute($request->route());
        if($request->user()->hasRole($roles) || !$roles){
            return $next($request);
        }
        return redirect()->route('izinDitolak');
    }

    public function ambilRoleRoute($route){
        $actions = $route->getAction();
        return isset($actions['roles']) ? $actions['roles'] : null;
    }
}
