<?php

namespace App\Events\User;


class LoggedOut {

}