<?php

namespace App\Events\User;

class LoggedIn {

}