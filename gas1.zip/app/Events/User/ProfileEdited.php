<?php
/**
 * User: amitavroy
 * Date: 12/02/17
 * Time: 8:53 PM
 */

namespace App\Events\User;

class ProfileEdited
{

}