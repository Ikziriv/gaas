<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PembeliStatus extends Model
{
    protected $table = 'pembeli_stats';
    protected $fillabel = ['name', 'slug'];
    protected $id = 'id';
    public $timestamps = false;

    public function pembeli(){
    	return $this->hasMany('App\Models\Pembeli', 'status_id', 'id');
    }
}
