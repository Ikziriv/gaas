<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Produk extends Model
{
    protected $fillable = [
        'name',
        'kategori_id', 
    ];

    public function detail_produk()
    {
        return $this->belongsToMany('App\Models\DetailProduk');
    }

    public function kategories()
    {
        return $this->belongsToMany('App\Models\Kategori');
    }
}
