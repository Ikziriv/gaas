<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pesanan extends Model
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'pesanans';

    protected $fillable = [
        'customer_id', 
        'produk_id', 
        'status_id'
    ];

    public function user()
    {
    	return $this->belongsTo('App\Models\User');
    }

    public function customer()
    {
        return $this->belongsTo('App\Models\Customer');
    }

    public function produk()
    {
        return $this->hasMany('App\Models\Produk');
    }

    public function status()
    {
        return $this->belongsTo('App\Models\PesananStatus');
    }
}
