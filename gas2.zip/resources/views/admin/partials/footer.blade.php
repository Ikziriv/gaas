<footer>
    <hr>
    <p class="pull-right">An Admin Area Manager by <a href="#" target="_blank">RID</a></p>
    <p>© 2017 <a href="#" target="_blank">RID</a></p>
</footer>