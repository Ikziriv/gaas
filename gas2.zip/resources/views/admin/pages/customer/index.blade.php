@extends('admin.layouts.master')

@section('title')
User
@endsection
@section('style')
<style type="text/css" media="screen">
.center {
    margin-top:50px;   
}

.modal-header {
  padding-bottom: 5px;
}

.modal-footer {
      padding: 0;
  }
    
.modal-footer .btn-group button {
  height:40px;
  border-top-left-radius : 0;
  border-top-right-radius : 0;
  border: none;
  border-right: 1px solid #ddd;
}
  
.modal-footer .btn-group:last-child > button {
  border-right: 0;
}
</style>
@endsection

@section('content')
<ul class="nav nav-pills pull-right">
  <li class="active"><a href="#"><i class="fa fa-file-excel-o"></i> Export</a></li>
</ul>
<div class="header">

    <h1 class="page-title">Customer Menu</h1>                 
    <ul class="breadcrumb">
        <li><a href="#">Home</a> </li>
        <li class="active">Customers</li>
    </ul>

</div>
<div class="main-content">
<div class="col-md-12">
  <div class="btn-toolbar list-toolbar">
    <div class="btn-group">
      <button class="btn btn-primary" id="add-customer">Add Customer</button>
    </div>
  </div>
</div>
<div class="panel panel-default">
  <div class="panel-body">
    <div class="col-md-12">
      <div class="table-responsive">
      <table id="customer" class="table">
        <thead>
          <tr>
            <th>#</th>
            <th>Status</th>
            <th>Nama</th>
            <th>Telphone</th>
            <th style="width: 3.5em;">Action</th>
          </tr>
        </thead>
        <tbody>
          @foreach ($customers as $key => $customer)
          <tr>
            <td>{{ $key +1 }}</td>
            @if($customer->active == 1)
            <td><span class="label label-success">Active</span></td>
            @else
            <td><span class="label label-danger">Passive</span></td>
            @endif
            <td><a href="customer/{{ $customer->id }}"><strong>{{ $customer->name }}</strong></a></td>
            <td>{{ $customer->tlp }}</td>
{{--             <td><a href="#" class="show-detail" data-id="{{ $customer->id }}" data-toggle="modal" data-target="#detail">Detail</a></td> --}}
            <td>
                <a href="#"><i class="fa fa-pencil"></i></a>
                <a href="#myModal" role="button" data-toggle="modal"><i class="fa fa-trash-o"></i></a>
            </td>
          </tr>
          @endforeach
        </tbody>
      </table>
      {{ $customers->links() }}
      </div>

    </div>
  </div>
</div>
</div>

{{-- modal form --}}
@include('admin.pages.customer.popup.customer')
@include('admin.pages.customer.popup.detail')
@endsection

@section('scripts')
<script type="text/javascript">
// Datatabel
$(document).ready(function() {
    $('#customer').DataTable( {
    responsive: true
} );
} );
// // Add customer click
// $('#add-customer').on('click', function() {
//   $('#show-form-customer').modal();
// })
// // Fetching ata modal checkout
// $(document).on('click', '.show-detail', function() {    
//     var user_id = $(this).data('id');
//     $.ajax({
//       url: '/customer/get-customer',
//       type: 'GET',
//       data: 'id='+user_id,
//       dataType: 'JSON',
//       success: function(data, textStatus, jqXHR){
//         var name = data.name;
//         var alamat = data.alamat;
//         var email = data.email;
//         $('.detail').html('<span><strong>' + name + '</strong></span>');
//         $('#show-form-detail').modal();
//         $('.alamat').html('<span><strong>' + alamat + '</strong></span>');
//         $('.email').html('<span><strong>' + email + '</strong></span>');
//       },
//       error: function(jqXHR, textStatus, errorThrown){

//       },
//     });    
//   });
</script>
</script>
@stop