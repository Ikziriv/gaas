@extends('admin.layouts.master')

@section('title')
Customer Detial Order
@endsection
@section('style')
<style type="text/css" media="screen">

</style>
@endsection

@section('content')
<ul class="nav nav-pills pull-right">
  <li class="active"><a href="#">Report</a></li>
</ul>
<div class="header">
    <h1 class="page-title">Detail Customer Order</h1>                 
    <ul class="breadcrumb">
        <li><a href="/">Home</a> </li>
        <li><a href="/produk">Customer</a> </li>
        <li class="active">Customer Order Detail</li>
    </ul>
</div>

<div class="main-content">
  <div class="col-md-12">
    <div class="btn-toolbar list-toolbar">
        <a href="/customer"><button class="btn btn-primary" id="add-customer">Kembali</button></a>
    </div>
  </div>
	<div class="col-md-12">
    <div class="invoice-title">
      <h2>Invoice <span class="label label-primary pull-right">Order Customer {{$customer->id}}</span></h2>
    </div>
    <hr>
    <div class="row">
      <div class="col-md-12">
        <address>
        <h3><strong>{{$customer->name}}</strong></h3><br>
          Description :<br>
          {{$customer->email}}<br>
          {{$customer->tlp}}<br>
          {{$customer->alamat}}<br>
        </address>
      </div>
      <div class="col-md-12">
      @forelse($orders as $key => $order)
      <div class="panel panel-default">
          <div class="panel-body">
        	  <div class="table-responsive">
              <table id="produk" class="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Produk Order</th>
                    <th>Qty</th>
                    <th>Tanggal</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{{ $key +1 }}</td>
                    <td>{{ $order->p_nama }}</td>
                    <td>{{ $order->qty }}</td>
                    <td>{{ Carbon::now()->toFormattedDateString($order->created_at) }}</td>
                    {{-- End --}}
                  </tr>
                </tbody>
                <tfoot>
                  <tr>
                    <th></th>
                    <th></th>
                    <th>{{$total}}</th>
                    <th></th>
                  </tr>
                </tfoot>
              </table>
              {{ $orders->links() }}
              </div>
            </div>
        </div>
        @empty
        <div class="col-md-12 text-center">
          <h1>:(</h1>
          <p>Order Not Found.</p>
        </div> 
        @endforelse
      </div>
    </div>
	</div>
</div>
@endsection

@section('scripts')
<script type="text/javascript">

</script>
@stop