
<!-- Modal -->
<div id="show-form-customer" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">

	  <form action="/" method="POST" class="form-horizontal">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add Customer</h4>
      </div>
      <div class="modal-body">
      <div class="row">
      	<div class="col-md-6">
          <div class="form-group">
            <label for="exampleInputEmail1">Full Name</label>
            <input type="email" class="form-control" id="nama" name="nama" placeholder="Ex: John Doe" required>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="exampleInputEmail1">Email</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Ex: jhon@doe.com" required>
          </div>
        </div>
        <div class="col-md-12">
          <div class="form-group">
            <label for="exampleInputEmail1">Telephone</label>
            <input type="text" class="form-control" id="tlp" name="tlp" placeholder="Ex: 08xxxxxx" required>
          </div>
        </div>
        <div class="col-md-12">
          <div class="form-group">
            <label for="exampleInputEmail1">Alamat</label>
            <textarea class="form-control" rows="3" required></textarea>
          </div>
        </div>
        <div class="col-md-12">
          <div class="checkbox">
            <label>
              <input type="checkbox" value="1"> Active
            </label>
          </div>
        </div>
      </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary" type="submit">Save</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
      </form>
    </div>

  </div>
</div>