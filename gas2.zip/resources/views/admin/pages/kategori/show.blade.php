@extends('admin.layouts.master')

@section('title')
Kategori View
@endsection
@section('style')
<style type="text/css" media="screen">

</style>
@endsection

@section('content')
<div class="header">

    <h1 class="page-title">Kategori View</h1>

</div>
<div class="main-content">


</div>

@endsection

@section('scripts')
<script type="text/javascript">

</script>
@stop