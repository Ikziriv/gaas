<ul class="nav nav-tabs nav-justified">
  <li><a href="#">TBG BG 5,5 KG <br> <span class="label label-primary">{{ $tbg1 }}</span></a></li>
  <li><a href="#">TBG ISI 5,5 KG <br> <span class="label label-primary">{{ $tbg2 }}</span></a></li>
  <li><a href="#">TBG 12 KG <br> <span class="label label-primary">{{ $tbg3 }}</span></a></li>
  <li><a href="#">ISI 12 KG <br> <span class="label label-primary">{{ $tbg4 }}</span></a></li>
  <li><a href="#">TBG BG 12 KG <br> <span class="label label-primary">{{ $tbg5 }}</span></a></li>
  <li><a href="#">ISI BG 12 KG <br> <span class="label label-primary">{{ $tbg6 }}</span></a></li>
</ul>