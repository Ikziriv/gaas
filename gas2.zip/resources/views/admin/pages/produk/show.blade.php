@extends('admin.layouts.master')

@section('title')
Produk View
@endsection
@section('style')
<style type="text/css" media="screen">

</style>
@endsection

@section('content')
<div class="header">

    <h1 class="page-title">Detail Produk Menu</h1>                 
    <ul class="breadcrumb">
        <li><a href="/">Home</a> </li>
        <li><a href="/produk">Inventory</a> </li>
        <li class="active">Detail Produk</li>
    </ul>

</div>

<div class="main-content">
  <div class="col-md-12">
    <div class="btn-toolbar list-toolbar">
        <a href="/produk"><button class="btn btn-primary" id="add-customer">Kembali</button></a>
    </div>
  </div>
	<div class="col-md-12">
    <div class="invoice-title">
      <h2>{{$produk->nama}} <span class="label label-primary pull-right">Total Stock : {{ $total }}</span></h2>
    </div>
    <hr>
	  <div class="table-responsive">
      <table id="produk" class="table">
        <thead>
          <tr>
            <th>#</th>
            <th>Stock</th>
            <th>Tanggal</th>
            <th style="width: 3.5em;">Action</th>
          </tr>
        </thead>
        <tbody>
          @foreach ($details as $key => $detail)
          <tr>
            <td>{{ $key +1 }}</td>
            <td>{{ $detail->stock }}</td>
            <td>{{ Carbon::now()->toFormattedDateString($detail->created_at) }}</td>
            {{-- End --}}
            <td>
                <a href="#"><i class="fa fa-pencil"></i></a>
                <a href="#myModal" role="button" data-toggle="modal"><i class="fa fa-trash-o"></i></a>
            </td>
          </tr>
          @endforeach
        </tbody>
      </table>
      </div>
	</div>
</div>
@endsection

@section('scripts')
<script type="text/javascript">

</script>
@stop