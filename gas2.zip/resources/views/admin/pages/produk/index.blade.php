@extends('admin.layouts.master')

@section('title')
Produk
@endsection
@section('style')
<style type="text/css" media="screen">

</style>
@endsection

@section('content')
<div class="header">

    <h1 class="page-title">Inventory Menu</h1>                 
    <ul class="breadcrumb">
        <li><a href="/">Home</a> </li>
        <li class="active">Inventory</li>
    </ul>

</div>

<div class="main-content">
  <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-body">
        @include('admin.pages.produk.partials.tab')
        <div class="table-responsive">
        <table id="produk" class="table">
          <thead>
            <tr>
              <th>#</th>
              <th>Nama</th>
              <th>Action</th>
              <th style="width: 3.5em;">Action</th>
            </tr>
          </thead>
          <tbody>
            @foreach ($produks as $key => $produk)
            <tr>
              <td>{{ $key +1 }}</td>
              <td><a href="produk/{{ $produk->id }}">{{ $produk->nama }}</a></td>
              {{-- End --}}
              <td>
                  <a href="#" class="create-modal" data-id="{{$produk->id}}" data-nama="{{$produk->nama}}"><i class="fa fa-plus"></i> Create</a>
              </td>
              <td>
                  <a href="#" class="edit-modal" data-id="{{$produk->id}}" data-nama="{{$produk->nama}}"><i class="fa fa-pencil"></i> Edit</a>
              </td>
            </tr>
            @endforeach
          </tbody>
          <tfoot>
            <tr>
              <th>#</th>
              <th>Nama</th>
              <th>Action</th>
              <th style="width: 3.5em;">Action</th>
            </tr>
          </tfoot>
        </table>
        {{ $produks->links() }}
        </div>
        </div>
      </div>
  </div>
</div>

<!-- Modal Create -->
<div id="createModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body">
        <div class="row">
          <form action="" class="form-horizontal" method="post" accept-charset="utf-8">
            <input type="hidden" class="form-control" id="id" name="id">
            <div class="col-md-12">
              <div class="form-group">
                <label for="exampleInputEmail1">Stock</label>
                <input type="text" class="form-control" id="stock" name="stock">
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">
          <span id="footer_btn"></span>
        </button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<div id="editModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body">
        <div class="row">
          <form action="" class="form-horizontal" method="post" accept-charset="utf-8">
            <input type="hidden" class="form-control" id="id" name="id">
            <div class="col-md-12">
              <div class="form-group">
                <label for="exampleInputEmail1">Nama</label>
                <input type="text" class="form-control" id="nama" name="nama">
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">
          <span id="footer_btn"></span>
        </button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
{{-- modal form --}}
@include('admin.pages.produk.popup.create')
@endsection

@section('scripts')
<script type="text/javascript">
  $(document).on('click', '.create-modal', function(){
    $('#footer_btn').text("Create");
    $('.modal-title').text('Create');
    $('.form-horizontal').show();
    $('#id').val($(this).data('id'));
    $('#nama').val($(this).data('nama'));
    $('#createModal').modal('show');
  });
  // click Modal
  $('.modal-footer').on('click', '.create', function(){
    $.ajax({
      type: 'post',
      url: '/createProduk',
      data: {
          '_token': $('input[name_token]').val(),
          'id': $("#id").val(),
          'stock': $("#stock").val()
      },
      success: function(data) {

      }
    });
  });
  // Edit Modal
  $(document).on('click', '.edit-modal', function(){
    $('#footer_btn').text("Edit");
    $('.modal-title').text('Edit');
    $('.form-horizontal').show();
    $('#id').val($(this).data('id'));
    $('#nama').val($(this).data('nama'));
    $('#createModal').modal('show');
  });
  // click Modal
  $('.modal-footer').on('click', '.create', function(){
    $.ajax({
      type: 'post',
      url: '/createProduk',
      data: {
          '_token': $('input[name_token]').val(),
          'id': $("#id").val(),
          'nama': $("#nama").val()
      },
      success: function(data) {

      }
    });
  });
</script>
<script type="text/javascript">
$(document).ready(function() {
    $('#produk').DataTable();
} );
// Add customer click
$('#add-produk').on('click', function() {
  $('#show-form-produk').modal();
})
</script>
@stop