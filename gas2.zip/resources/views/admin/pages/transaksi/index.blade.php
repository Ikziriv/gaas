@extends('admin.layouts.master')

@section('title')
Purchase Order
@endsection
@section('style')
<style type="text/css" media="screen">
</style>
@endsection

@section('content') 
<ul class="nav nav-pills pull-right">
  <li class="active"><a href="#">Daily</a></li>
  <li class="active"><a href="#">Monthly</a></li>
</ul>
<div class="header">

    <h1 class="page-title">Order Menu</h1>                 
    <ul class="breadcrumb">
        <li><a href="/">Home</a> </li>
        <li class="active">Order</li>
    </ul>

</div>

<div class="main-content">
<div class="col-md-12">
  <div class="btn-toolbar list-toolbar">
      <a href="{{ route('transaksi.create')}}"><button class="btn btn-primary">Add Order</button></a>
    <div class="btn-group">
    </div>
  </div>
</div>
<div class="panel panel-default">
  <div class="panel-body">
    <div class="col-md-12">
        <ul class="nav nav-tabs">
          <li class="active">
            <a href="{!! url('transaksi/sort') !!}">
              All <span class="label label-default">{{  $counts['total'] }}</span>
            </a>
          </li>
          @foreach ($status as $stat)
          <li>
            <a href="{!! url('transaksi/sort/'. $stat->slug) !!}">
              {{ $stat->name }} 
              @if($stat->slug == 'new')
              <span class="label label-primary">{{ $counts[$stat->slug] }}</span>
              @elseif($stat->slug == 'otw')
              <span class="label label-warning">{{ $counts[$stat->slug] }}</span>
              @else
              <span class="label label-success">{{ $counts[$stat->slug] }}</span>
              @endif
            </a>
          </li>
          @endforeach
        </ul>
        <div class="table-responsive"><br>
        <table class="table" id="transaksi">
          <thead>
            <tr>
              <th>#</th>
              <th>Status</th>
              <th>Nama</th>
              <th>Phone</th>
              <th>Qty</th>
            </tr>
          </thead>
          <tbody>
            @foreach ($transaksis as $key => $transaksi)
            <tr>
              <td>{{ $key +1 }}</td>
              @if($transaksi->status_id == 2)
              <td><span class="label label-warning">Otw</span></td>
              @elseif($transaksi->status_id == 3)
              <td><span class="label label-success">Completed</span></td>
              @else
              <td><span class="label label-primary">New</span></td>
              @endif
              <td><strong>{{ $transaksi->customer->name }}</strong></td>
              <td>{{ $transaksi->customer->tlp}}</td>
              <td>{{ $transaksi->qty}}</td>
            </tr>
            @endforeach
          </tbody>
        </table>
        </div>
    </div>
  </div>

  </div>
</div>
{{-- Modal --}}
@include('admin.pages.transaksi.popup.order')
@include('admin.pages.transaksi.popup.detail')
@endsection

@section('scripts')
<script type="text/javascript">
$(document).ready(function() {
    $('#transaksi').DataTable();
} );

// Fetching ata modal checkout
$(document).on('click', '.show-detail', function() {    
    var user_id = $(this).data('id');
    $.ajax({
      url: 'transaksi/get-customer',
      type: 'GET',
      data: 'id='+user_id,
      dataType: 'JSON',
      success: function(data, textStatus, jqXHR){
        var cname = data.customers.name;
        var alamat = data.alamat;
        var email = data.email;
        $('.detail').html('<span><strong>' + cname + '</strong></span>');
        $('#show-form-detail').modal();
        $('.alamat').html('<span><strong>' + alamat + '</strong></span>');
        $('.email').html('<span><strong>' + email + '</strong></span>');
      },
      error: function(jqXHR, textStatus, errorThrown){

      },
    });    
  });
</script>
@stop