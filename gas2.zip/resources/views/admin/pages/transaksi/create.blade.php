@extends('admin.layouts.master')

@section('title')
Transaksi Create
@endsection
@section('style')
<style type="text/css" media="screen">

</style>
@endsection

@section('content')
<div class="header">

    <h1 class="page-title">Order Create</h1>         
    <h4 class="pull-right">Cashier : {{Auth::user()->name}}</h4>    
    <ul class="breadcrumb">
        <li><a href="/">Home</a> </li>
        <li><a href="{{route('transaksi.index')}}">Order</a></li>
        <li class="active">Order Create</li>
    </ul>

</div>
<div class="main-content">

      <div class="row">
      <div class="col-md-6">
          <form action="/" method="POST" class="form-horizontal">
          <div class="col-md-12">
              <div class="form-group">
                <label for="exampleInputEmail1">Nama</label>
                <select class="form-control" name="name">
                @foreach ($cnames as $key => $value)
                    <option value="{{ $key }}">{{ $value }}</option>
                @endforeach
                </select>
              </div>
          </div>
          <div class="col-md-6">
              <div class="form-group">
                <label for="exampleInputEmail1">Phone</label>
                <select class="form-control" name="name">
                @foreach ($ctlp as $key => $value)
                    <option value="{{ $key }}">{{ $value }}</option>
                @endforeach
                </select>
              </div>
          </div>
          <div class="col-md-6">
              <div class="form-group">
                <label for="exampleInputEmail1"><br></label>
                <select class="form-control" name="name">
                @foreach ($ctlp as $key => $value)
                    <option value="{{ $key }}">{{ $value }}</option>
                @endforeach
                </select>
              </div>
          </div>
          <div class="col-md-12">
          <hr>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputEmail1">Jenis Barang</label>
              <input type="number" class="form-control" id="tbg1" name="tbg1" min="0" max="99" pattern="\d+">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputEmail1">Qty</label>
              <input type="number" class="form-control" id="tbg1" name="tbg1" min="0" max="99" pattern="\d+">
            </div>
          </div>

          <div class="col-md-12">
            <div class="form-group pull-left">
              <button class="btn btn-primary" type="submit">Order</button>
            </div>
          </div>

          </form>

        </div>


        <div class="col-md-6">

        <form class="form-horizontal" method="POST" action="/">
        <div class="col-md-6">
          <div class="form-group">
            <label for="exampleInputEmail1">Full Name</label>
            <input type="email" class="form-control" id="nama" name="nama" placeholder="Ex: John Doe" required>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="exampleInputEmail1">Email</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Ex: jhon@doe.com" required>
          </div>
        </div>
        <div class="col-md-12">
          <div class="form-group">
            <label for="exampleInputEmail1">Telephone</label>
            <input type="text" class="form-control" id="tlp" name="tlp" placeholder="Ex: 08xxxxxx" required>
          </div>
        </div>
        <div class="col-md-12">
          <div class="checkbox pull-right">
            <label>
              <input type="checkbox" value="1"> Active
            </label>
          </div>
        </div>
        <div class="col-md-12">
          <div class="form-group">
            <label for="exampleInputEmail1">Alamat</label>
            <textarea class="form-control" rows="3" required></textarea>
          </div>
        </div>
        <div class="col-md-12">
          <div class="form-group pull-right">
            <button class="btn btn-primary" type="submit">Save</button>
          </div>
        </div>

        </form>

        </div>
      </div>
      </div>

</div>

@endsection

@section('scripts')
<script type="text/javascript">

</script>
@stop