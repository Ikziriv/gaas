<template>
    <div class="col-md-12">
        <panel>
        <p>
        Test
        </p>
        </panel>
    </div>
</template>
<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>