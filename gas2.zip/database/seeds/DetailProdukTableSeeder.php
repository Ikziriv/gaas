<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use App\Models\DetailProduk;

class DetailProdukTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		DetailProduk::create([
			'detial_produk_id' => 1,
			'stock' => '5',
		]);
		DetailProduk::create([
			'detial_produk_id' => 1,
			'stock' => '10',
		]);

		DetailProduk::create([
			'detial_produk_id' => 2,
			'stock' => '5',
		]);
		DetailProduk::create([
			'detial_produk_id' => 2,
			'stock' => '10',
		]);

		DetailProduk::create([
			'detial_produk_id' => 3,
			'stock' => '5',
		]);
		DetailProduk::create([
			'detial_produk_id' => 3,
			'stock' => '10',
		]);

		DetailProduk::create([
			'detial_produk_id' => 4,
			'stock' => '5',
		]);
		DetailProduk::create([
			'detial_produk_id' => 4,
			'stock' => '10',
		]);

		DetailProduk::create([
			'detial_produk_id' => 5,
			'stock' => '5',
		]);
		DetailProduk::create([
			'detial_produk_id' => 5,
			'stock' => '10',
		]);

		DetailProduk::create([
			'detial_produk_id' => 6,
			'stock' => '5',
		]);
		DetailProduk::create([
			'detial_produk_id' => 6,
			'stock' => '10',
		]);
    }
}
