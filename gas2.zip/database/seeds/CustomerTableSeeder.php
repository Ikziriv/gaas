<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use App\Models\Customer;

class CustomerTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		Customer::create([
			'name' => 'Anton Sinaga',
			'email' => 'anton@gmail.com',
			'alamat' => 'Jl Gandaria Selatan no 7',
			'tlp' => '0811665532',
			'active' => true
		]);

		Customer::create([
			'name' => 'Jhon Regges',
			'email' => 'john@gmail.com',
			'alamat' => 'Jl Gandaria Selatan no 7',
			'tlp' => '0811665532',
			'active' => true
		]);

		Customer::create([
			'name' => 'Regges Irfin',
			'email' => 'regges@gmail.com',
			'alamat' => 'Jl Gandaria Selatan no 7',
			'tlp' => '0811665532',
			'active' => true
		]);

		Customer::create([
			'name' => 'Arnav Daron',
			'email' => 'arnav@gmail.com',
			'alamat' => 'Jl Gandaria Selatan no 7',
			'tlp' => '0811665532',
			'active' => true
		]);
    }
}
