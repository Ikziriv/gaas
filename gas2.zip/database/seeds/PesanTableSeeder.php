<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use App\Models\Pesanan;

class PesanTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
		Pesanan::create([
			'customer_id' => 1,
			'produk_id' => 1,
            'status_id' => 1,
            'qty' => 10
		]);
        Pesanan::create([
            'customer_id' => 2,
            'produk_id' => 2,
            'status_id' => 2,
            'qty' => 5
        ]);
        Pesanan::create([
            'customer_id' => 3,
            'produk_id' => 3,
            'status_id' => 3,
            'qty' => 7
        ]);
    }
}
