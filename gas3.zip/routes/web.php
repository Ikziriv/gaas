<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'LoginController@getLogin')->name('login');
Route::post('/login', 'LoginController@postLogin');


Route::group(['middleware' => 'auth'], function () {
    // Auth
    Route::get('/logout', 'LoginController@getLogout')->name('logout');
    // Admin
    Route::get('/admin', 'TransaksiController@index')->name('admin');
    // Kategori
    Route::resource('kategori', 'KategoriController',[
    	'except' => 'show'
    ]);
    // Produk
    Route::resource('produk', 'ProdukController');
    Route::post('createProduk', 'ProdukController@createProduk');
    Route::post('editProduk', 'ProdukController@editProduk');
    // User
    Route::resource('user', 'UserController',[
    	'except' => 'show'
    ]);
    Route::get('user/profile', 'UserController@pageUserProfile')->name('profile');
    Route::post('user/profile', 'UserController@postUpdateProfile')->name('update-profile');
    Route::get('user/activities', 'UserController@pageActivities')->name('activities');
    Route::post('user/password-change','UserController@postHandlePasswordChange')->name('change-password');
    // Customer
    Route::resource('customer', 'CustomerController');
    Route::get('/customer/get-customer', 'CustomerController@getCustomer');
    Route::get('/customer/produk/{id}', 'CustomerController@getPrice');
    // Transaksi
    Route::resource('transaksi', 'TransaksiController',[
    	'except' => 'show'
    ]);
    Route::get('transaksi/get-customer', 'TransaksiController@getCustomer');
    Route::get('transaksi/report', 'TransaksiController@getReport');
    Route::get('transaksi/sort/{stat?}', 'TransaksiController@index');
});

Route::group(['prefix' => 'api/'], function() {
    Route::resource('invoice', 'InvoiceController');
});

