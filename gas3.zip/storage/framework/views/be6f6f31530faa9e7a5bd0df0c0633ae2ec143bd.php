<!doctype html>
<html lang="en"><head>
    <meta charset="utf-8">
    <title>Administration Manager</title>
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('back/lib/bootstrap/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('back/lib/font-awesome/css/font-awesome.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('back/stylesheets/theme.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('back/stylesheets/premium.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(url('css/dataTables.bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/responsive.dataTables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/animate.css')); ?>">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
    <style type="text/css">
        #line-chart {
            height:300px;
            width:800px;
            margin: 0px auto;
            margin-top: 1em;
        }
        .navbar-default .navbar-brand, .navbar-default .navbar-brand:hover { 
            color: #fff;
        }
    </style>
</head>
<body class=" theme-blue">

    <?php echo $__env->make('admin.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content">
        <div id="app">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <?php echo $__env->yieldContent('scripts'); ?>
    <script src="<?php echo e(url('js/jquery-3.2.0.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('back/lib/bootstrap/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(url('js/datatables.bootstrap.js')); ?>"></script>

    <script type="text/javascript">
        $("[rel=tooltip]").tooltip();
        $(function() {
            $('.demo-cancel-click').click(function(){return false;});
        });
        // 
        // 
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("select").select2();
            $('.datepicker').datepicker({
                todayBtn: "linked",
                orientation: "bottom auto",
                format: 'yyyy-mm-dd'
            });
        }); 
    </script>
    <script src="<?php echo e(url('back/lib/jQuery-Knob/js/jquery.knob.js')); ?>" type="text/javascript"></script>
    <script type="text/javascript">
        $(function() {
            $(".knob").knob();
        });
    </script>
    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>

    <?php echo $__env->make('admin.partials.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
  
</body>

</html>
