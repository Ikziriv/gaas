<?php $__env->startSection('title'); ?>
Activities
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<style type="text/css" media="screen">

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<ul class="nav nav-pills pull-right">
  <li class="active"><a href="#">Delete All</a></li>
</ul>
<div class="header">

    <h1 class="page-title">User Activities</h1>             
    <ul class="breadcrumb">
        <li><a href="#">Home</a> </li>
        <li><a href="#">User</a></li>
        <li class="active">Activities</li>
    </ul>

</div>
<div class="main-content">

<div class="col-md-12">
  <?php if($options != null): ?>
    <form action="<?php echo e(route('activities')); ?>" method="get" class="">
      <div class="row gap-bottom gap-20">
        <div class="col-sm-6">
          <div class="form-group">
            <input type="text"
                   name="search_text"
                   placeholder="Search a description"
                   value="<?php echo e($options['search_text']); ?>"
                   class="form-control" />
          </div>
        </div>

        <div class="col-sm-3">
          <div class="form-group">
            <select name="level" id="level" class="form-control">
              <option value="">Select</option>
              <option value="info" <?php echo e(($options['level'] === 'info') ? 'selected' : ''); ?>>Info</option>
              <option value="warning" <?php echo e(($options['level'] === 'warning') ? 'selected' : ''); ?>>Warning</option>
              <option value="danger" <?php echo e(($options['level'] === 'danger') ? 'selected' : ''); ?>>Danger</option>
            </select>
          </div>
        </div>

        <div class="col-sm-3">
          <button class="btn btn-success">
            <i class="fa fa-filter"></i> Filter
          </button>
          <a href="<?php echo e(route('activities')); ?>" class="btn btn-primary">Reset</a>
        </div>
      </div>
    </form>
  <?php endif; ?>
</div>

<div class="col-md-12">
  <div class="row">
    <div class="col-sm-12 gap-bottom gap-10">
      <strong>Total: </strong><?php echo e($rows->total()); ?>

    </div>
  </div>
</div>

<div class="col-md-12">
  <div class="table-responsive">
    <table class="table">
      <thead>
      <tr>
        <th>#</th>
        <th>Description</th>
        <th>Level</th>
        <th>IP Address</th>
        <th>User id</th>
        <th>Time</th>
      </tr>
      </thead>

      <tbody>
      <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $watchdog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($watchdog->id); ?></td>
          <td><?php echo e($watchdog->description); ?></td>
          <?php if($watchdog->level = 'info'): ?>
          <td><span class="label label-info"><?php echo e($watchdog->level); ?></span></td>
          <?php elseif($watchdog->level = 'warning'): ?>
          <td><span class="label label-warning"><?php echo e($watchdog->level); ?></span></td>
          <?php else: ?>
          <td><span class="label label-danger"><?php echo e($watchdog->level); ?></span></td>
          <?php endif; ?>
          <td><?php echo e($watchdog->ip_address); ?></td>
          <td><?php echo e($watchdog->user_id); ?></td>
          <td><?php echo e($watchdog->created_at); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

    <?php if($options != null): ?>
      <?php echo e($rows->appends($options)->links()); ?>

    <?php else: ?>
      <?php echo e($rows->render()); ?>

    <?php endif; ?>

  </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>