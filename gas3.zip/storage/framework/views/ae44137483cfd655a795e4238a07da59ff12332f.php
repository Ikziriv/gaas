<?php $__env->startSection('title'); ?>
Produk View
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<style type="text/css" media="screen">

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="header">

    <h1 class="page-title">Detail Produk Menu</h1>                 
    <ul class="breadcrumb">
        <li><a href="/">Home</a> </li>
        <li><a href="/produk">Inventory</a> </li>
        <li class="active">Detail Produk</li>
    </ul>

</div>

<div class="main-content">
  <div class="col-md-12">
    <div class="btn-toolbar list-toolbar">
        <a href="/produk"><button class="btn btn-primary" id="add-customer">Kembali</button></a>
    </div>
  </div>
	<div class="col-md-12">
    <div class="invoice-title">
      <h2><?php echo e($produk->nama); ?> <span class="label label-primary pull-right">Total Stock : <?php echo e($total); ?></span></h2>
    </div>
    <hr>
	  <div class="table-responsive">
      <table id="produk" class="table">
        <thead>
          <tr>
            <th>#</th>
            <th>Stock</th>
            <th>Tanggal</th>
            <th style="width: 3.5em;">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($key +1); ?></td>
            <td><?php echo e($detail->stock); ?></td>
            <td><?php echo e(Carbon::now()->toFormattedDateString($detail->created_at)); ?></td>
            
            <td>
                <a href="#"><i class="fa fa-pencil"></i></a>
                <a href="#myModal" role="button" data-toggle="modal"><i class="fa fa-trash-o"></i></a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      </div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>