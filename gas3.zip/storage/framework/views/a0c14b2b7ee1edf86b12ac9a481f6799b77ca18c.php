
<!-- Modal -->
<div id="show-form-produk" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">

      <form action="/" method="POST" class="form-horizontal">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add Stock</h4>
      </div>
      <div class="modal-body">
      <div class="row">
        <div class="col-md-12">
          <div class="form-group">
            <label for="exampleInputEmail1">Tanggal</label>
            <input type="text" class="form-control datepicker" id="tgl" name="tgl">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="exampleInputEmail1">TBG BG 5,5</label>
            <input type="number" class="form-control" id="tbg1" name="tbg1" min="0" max="99" pattern="\d+">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="exampleInputEmail1">ISI BG 5,5</label>
            <input type="number" class="form-control" id="tbg2" name="tbg2" min="0" max="99" pattern="\d+">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="exampleInputEmail1">TBG 12</label>
            <input type="number" class="form-control" id="tbg3" name="tbg3" min="0" max="99" pattern="\d+">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="exampleInputEmail1">ISI 12</label>
            <input type="number" class="form-control" id="tbg4" name="tbg4" min="0" max="99" pattern="\d+">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="exampleInputEmail1">TBG BG 12</label>
            <input type="number" class="form-control" id="tbg5" name="tbg5" min="0" max="99" pattern="\d+">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label for="exampleInputEmail1">ISI BG 12</label>
            <input type="number" class="form-control" id="tbg6" name="tbg6" min="0" max="99" pattern="\d+">
          </div>
        </div>
      </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary" type="submit">Save</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
      </form>
    </div>

  </div>
</div>