<form role="form" method="POST" action="<?php echo e(url('login')); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
    	<label class="sr-only" for="form-username"><?php echo e($title1); ?></label>
    	<input type="text" id="username" name="username" placeholder="Email..." class="form-control">
        <div class="HelpText error"><?php echo e($errors->first('username')); ?></div>
    </div>
    <div class="form-group">
    	<label class="sr-only" for="form-password"><?php echo e($title2); ?></label>
    	<input type="password" id="password" name="password" placeholder="Password..." class="form-control">
        <div class="HelpText error"><?php echo e($errors->first('password')); ?></div>
    </div>
      <div class="checkbox">
        <label>
          <input id="memory" type="checkbox" name="remember" value="1"> Remember me
        </label>
      </div>
    <button type="submit" class="btn btn-primary"><?php echo e($button_form); ?></button>
</form>