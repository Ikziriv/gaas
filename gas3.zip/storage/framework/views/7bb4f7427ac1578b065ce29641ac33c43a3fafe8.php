<?php $__env->startSection('title'); ?>
Customer Detial Order
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<style type="text/css" media="screen">

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<ul class="nav nav-pills pull-right">
  <li class="active"><a href="#">Report</a></li>
</ul>
<div class="header">
    <h1 class="page-title">Detail Customer Order</h1>                 
    <ul class="breadcrumb">
        <li><a href="/">Home</a> </li>
        <li><a href="/produk">Customer</a> </li>
        <li class="active">Customer Order Detail</li>
    </ul>
</div>

<div class="main-content">
  <div class="col-md-12">
    <div class="btn-toolbar list-toolbar">
        <a href="/customer"><button class="btn btn-primary" id="add-customer">Kembali</button></a>
    </div>
  </div>
	<div class="col-md-12">
    <div class="invoice-title">
      <h2>Invoice <span class="label label-primary pull-right">Order Customer <?php echo e($customer->id); ?></span></h2>
    </div>
    <hr>
    <div class="row">
      <div class="col-md-12">
        <address>
        <h3><strong><?php echo e($customer->name); ?></strong></h3><br>
          Description :<br>
          <?php echo e($customer->email); ?><br>
          <?php echo e($customer->tlp); ?><br>
          <?php echo e($customer->alamat); ?><br>
        </address>
      </div>
      <div class="col-md-12">
      <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="panel panel-default">
          <div class="panel-body">
        	  <div class="table-responsive">
              <table id="produk" class="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Produk Order</th>
                    <th>Qty</th>
                    <th>Tanggal</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><?php echo e($key +1); ?></td>
                    <td><?php echo e($order->p_nama); ?></td>
                    <td><?php echo e($order->qty); ?></td>
                    <td><?php echo e(Carbon::now()->toFormattedDateString($order->created_at)); ?></td>
                    
                  </tr>
                </tbody>
                <tfoot>
                  <tr>
                    <th></th>
                    <th></th>
                    <th><?php echo e($total); ?></th>
                    <th></th>
                  </tr>
                </tfoot>
              </table>
              <?php echo e($orders->links()); ?>

              </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-md-12 text-center">
          <h1>:(</h1>
          <p>Order Not Found.</p>
        </div> 
        <?php endif; ?>
      </div>
    </div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>