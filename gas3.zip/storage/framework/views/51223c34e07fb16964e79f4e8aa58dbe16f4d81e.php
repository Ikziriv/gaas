<div class="sidebar-nav">
<ul>

    
    <li>
        <a href="<?php echo e(route('transaksi.index')); ?>" class="nav-header collapsed">
            <i class="fa fa-fw fa-usd"></i> Order
        </a>
    </li>
    
    <li>
        <a href="<?php echo e(route('produk.index')); ?>" class="nav-header collapsed">
            <i class="fa fa-folder"></i> Inventory
        </a>
    </li>
    
    <li>
        <a href="<?php echo e(route('customer.index')); ?>" class="nav-header collapsed">
            <i class="fa fa-fw fa-briefcase"></i> Customer
        </a>
    </li>
    
    <li>
        <a href="<?php echo e(route('activities')); ?>" class="nav-header collapsed">
            <i class="fa fa-fw fa-user"></i> Users Logs
        </a>
    </li>
    
    <li><a href="#" class="nav-header"><i class="fa fa-fw fa-question-circle"></i> Help</a></li>

</ul>
</div>