<?php $__env->startSection('title'); ?>
Purchase Order
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<style type="text/css" media="screen">
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
<ul class="nav nav-pills pull-right">
  <li class="active"><a href="#">Daily</a></li>
  <li class="active"><a href="#">Monthly</a></li>
</ul>
<div class="header">

    <h1 class="page-title">Order Menu</h1>                 
    <ul class="breadcrumb">
        <li><a href="/">Home</a> </li>
        <li class="active">Order</li>
    </ul>

</div>

<div class="main-content">
<div class="col-md-12">
  <div class="btn-toolbar list-toolbar">
      <a href="<?php echo e(route('transaksi.create')); ?>"><button class="btn btn-primary">Add Order</button></a>
    <div class="btn-group">
    </div>
  </div>
</div>
<div class="panel panel-default">
  <div class="panel-body">
    <div class="col-md-12">
        <ul class="nav nav-tabs">
          <li class="active">
            <a href="<?php echo url('transaksi/sort'); ?>">
              All <span class="label label-default"><?php echo e($counts['total']); ?></span>
            </a>
          </li>
          <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li>
            <a href="<?php echo url('transaksi/sort/'. $stat->slug); ?>">
              <?php echo e($stat->name); ?> 
              <?php if($stat->slug == 'new'): ?>
              <span class="label label-primary"><?php echo e($counts[$stat->slug]); ?></span>
              <?php elseif($stat->slug == 'otw'): ?>
              <span class="label label-warning"><?php echo e($counts[$stat->slug]); ?></span>
              <?php else: ?>
              <span class="label label-success"><?php echo e($counts[$stat->slug]); ?></span>
              <?php endif; ?>
            </a>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="table-responsive"><br>
        <table class="table" id="transaksi">
          <thead>
            <tr>
              <th>#</th>
              <th>Status</th>
              <th>Nama</th>
              <th>Phone</th>
              <th>Qty</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($key +1); ?></td>
              <?php if($transaksi->status_id == 2): ?>
              <td><span class="label label-warning">Otw</span></td>
              <?php elseif($transaksi->status_id == 3): ?>
              <td><span class="label label-success">Completed</span></td>
              <?php else: ?>
              <td><span class="label label-primary">New</span></td>
              <?php endif; ?>
              <td><strong><?php echo e($transaksi->customer->name); ?></strong></td>
              <td><?php echo e($transaksi->customer->tlp); ?></td>
              <td><?php echo e($transaksi->qty); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        </div>
    </div>
  </div>

  </div>
</div>

<?php echo $__env->make('admin.pages.transaksi.popup.order', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.pages.transaksi.popup.detail', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
$(document).ready(function() {
    $('#transaksi').DataTable();
} );

// Fetching ata modal checkout
$(document).on('click', '.show-detail', function() {    
    var user_id = $(this).data('id');
    $.ajax({
      url: 'transaksi/get-customer',
      type: 'GET',
      data: 'id='+user_id,
      dataType: 'JSON',
      success: function(data, textStatus, jqXHR){
        var cname = data.customers.name;
        var alamat = data.alamat;
        var email = data.email;
        $('.detail').html('<span><strong>' + cname + '</strong></span>');
        $('#show-form-detail').modal();
        $('.alamat').html('<span><strong>' + alamat + '</strong></span>');
        $('.email').html('<span><strong>' + email + '</strong></span>');
      },
      error: function(jqXHR, textStatus, errorThrown){

      },
    });    
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>