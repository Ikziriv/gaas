<?php $__env->startSection('title'); ?>
Produk
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<style type="text/css" media="screen">

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="header">

    <h1 class="page-title">Inventory Menu</h1>                 
    <ul class="breadcrumb">
        <li><a href="/">Home</a> </li>
        <li class="active">Inventory</li>
    </ul>

</div>

<div class="main-content">
  <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-body">
        <?php echo $__env->make('admin.pages.produk.partials.tab', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="table-responsive">
        <table id="produk" class="table">
          <thead>
            <tr>
              <th>#</th>
              <th>Nama</th>
              <th>Action</th>
              <th style="width: 3.5em;">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($key +1); ?></td>
              <td><a href="produk/<?php echo e($produk->id); ?>"><?php echo e($produk->nama); ?></a></td>
              
              <td>
                  <a href="#" class="create-modal" data-id="<?php echo e($produk->id); ?>" data-nama="<?php echo e($produk->nama); ?>"><i class="fa fa-plus"></i> Create</a>
              </td>
              <td>
                  <a href="#" class="edit-modal" data-id="<?php echo e($produk->id); ?>" data-nama="<?php echo e($produk->nama); ?>"><i class="fa fa-pencil"></i> Edit</a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tfoot>
            <tr>
              <th>#</th>
              <th>Nama</th>
              <th>Action</th>
              <th style="width: 3.5em;">Action</th>
            </tr>
          </tfoot>
        </table>
        <?php echo e($produks->links()); ?>

        </div>
        </div>
      </div>
  </div>
</div>

<!-- Modal Create -->
<div id="createModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body">
        <div class="row">
          <form action="" class="form-horizontal" method="post" accept-charset="utf-8">
            <input type="hidden" class="form-control" id="id" name="id">
            <div class="col-md-12">
              <div class="form-group">
                <label for="exampleInputEmail1">Stock</label>
                <input type="text" class="form-control" id="stock" name="stock">
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">
          <span id="footer_btn"></span>
        </button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<div id="editModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body">
        <div class="row">
          <form action="" class="form-horizontal" method="post" accept-charset="utf-8">
            <input type="hidden" class="form-control" id="id" name="id">
            <div class="col-md-12">
              <div class="form-group">
                <label for="exampleInputEmail1">Nama</label>
                <input type="text" class="form-control" id="nama" name="nama">
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">
          <span id="footer_btn"></span>
        </button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<?php echo $__env->make('admin.pages.produk.popup.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
  $(document).on('click', '.create-modal', function(){
    $('#footer_btn').text("Create");
    $('.modal-title').text('Create');
    $('.form-horizontal').show();
    $('#id').val($(this).data('id'));
    $('#nama').val($(this).data('nama'));
    $('#createModal').modal('show');
  });
  // click Modal
  $('.modal-footer').on('click', '.create', function(){
    $.ajax({
      type: 'post',
      url: '/createProduk',
      data: {
          '_token': $('input[name_token]').val(),
          'id': $("#id").val(),
          'stock': $("#stock").val()
      },
      success: function(data) {

      }
    });
  });
  // Edit Modal
  $(document).on('click', '.edit-modal', function(){
    $('#footer_btn').text("Edit");
    $('.modal-title').text('Edit');
    $('.form-horizontal').show();
    $('#id').val($(this).data('id'));
    $('#nama').val($(this).data('nama'));
    $('#createModal').modal('show');
  });
  // click Modal
  $('.modal-footer').on('click', '.create', function(){
    $.ajax({
      type: 'post',
      url: '/createProduk',
      data: {
          '_token': $('input[name_token]').val(),
          'id': $("#id").val(),
          'nama': $("#nama").val()
      },
      success: function(data) {

      }
    });
  });
</script>
<script type="text/javascript">
$(document).ready(function() {
    $('#produk').DataTable();
} );
// Add customer click
$('#add-produk').on('click', function() {
  $('#show-form-produk').modal();
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>