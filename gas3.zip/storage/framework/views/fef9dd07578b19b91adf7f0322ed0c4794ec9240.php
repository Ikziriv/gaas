<!-- Javascript -->
<script src="front/assets/js/jquery-1.11.1.min.js"></script>
<script src="front/assets/bootstrap/js/bootstrap.min.js"></script>
<script src="js/sweetalert.min.js"></script>

<!--[if lt IE 10]>
    <script src="assets/js/placeholder.js"></script>
<![endif]-->