<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title>Login</title>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
        <?php echo $__env->make('login.partials.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </head>

    <body>
        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Top content -->
        <div class="top-content">
        	
            <div class="inner-bg">
                <div class="container">
                    <div class="row">
                    <?php $__env->startComponent('login.components.body'); ?>
                        <?php $__env->slot('title'); ?>
                            Login
                        <?php $__env->endSlot(); ?>
                        <?php $__env->slot('sub_title'); ?>
                            Fill in the form below to get access:
                        <?php $__env->endSlot(); ?>
                        <?php $__env->slot('icon'); ?>
                            fa-paper-plane
                        <?php $__env->endSlot(); ?>
                    <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
            
        </div>

        <?php echo $__env->make('login.partials.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('admin.partials.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </body>

</html>