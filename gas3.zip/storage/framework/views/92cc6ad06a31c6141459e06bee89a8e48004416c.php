<div class="col-sm-3">
</div>
<div class="col-sm-6 form-box">
	<div class="form-top">
		<div class="form-top-left">
			<h3><strong><?php echo e($title); ?></strong></h3>
    		<p><?php echo e($sub_title); ?></p>
		</div>
		<div class="form-top-right">
			<i class="fa <?php echo e($icon); ?>"></i>
		</div>
		<div class="form-top-divider"></div>
    </div>
    <div class="form-bottom">
        <?php $__env->startComponent('login.components.form'); ?>
            <?php $__env->slot('title1'); ?>
                Email
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('title2'); ?>
                Password
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('button_form'); ?>
                Login
            <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
    </div>
</div>