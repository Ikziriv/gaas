<!-- CSS -->
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
<link rel="stylesheet" href="front/assets/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="front/assets/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="front/assets/css/form-elements.css">
<link rel="stylesheet" href="front/assets/css/style.css">
<link rel="stylesheet" href="css/sweetalert.css">
<!-- Favicon and touch icons -->
<link rel="shortcut icon" href="front/assets/ico/favicon.png">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="front/assets/ico/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="front/assets/ico/apple-touch-icon-114-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="front/assets/ico/apple-touch-icon-72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="front/assets/ico/apple-touch-icon-57-precomposed.png">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('css/animate.css')); ?>">